package models

type Spec struct {
	ApiSpecs []ApiSpec
}
