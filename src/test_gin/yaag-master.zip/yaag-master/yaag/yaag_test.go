package yaag

import (
	"testing"
)

func TestYaag(t *testing.T) {
	t.Skip(true)
}
